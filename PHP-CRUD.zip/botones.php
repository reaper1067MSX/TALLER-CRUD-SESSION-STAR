<html>
	<head>
		<title> - Formulario -</title>
	</head>
	<body>
	<!--boton consultar -->

		<form id="consultar" action="consultar.php" method="get">
			<input type="submit" name="consultar" value ="consultar">
		</form>

		<!--boton eliminar -->
		<form id="borrar" action="borrar.php" method="get">
			<input type="submit" name="borrar" value ="borrar">
		</form>
		<!--actualizar -->
		<form id="actualizar" action="actualizar.php" method="get">
			<input type="submit" name="actualizar" value ="actualizar">
		</form>
		<!--insertar -->
		<form id="insertar" action="insertar.php" method="get">
			<input type="submit" name="insertar" value ="insertar">
		</form>

	</body>

</html>
