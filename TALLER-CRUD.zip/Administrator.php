<?php

?>


<html>
	<head>
		<title> - Administrador de contenido - </title>
	</head>
	<body>
		
		<h2><center>Administracion del sitio</center></h2>
		<br>
		
		<a href="DemoList.php">DemoList</a>
		
				
		
	</body>
</html>
	